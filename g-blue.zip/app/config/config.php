<?php
$oc_config = array (
    
    //================================================================================================
   

    "favicon"         => "favicon.gif" ,

    //================================================================================================

    "sitelogo"        => "Movie Series Online",
    
    "sitename"        => "Movie Series Online",

    "sitedescription" => "Watch Full Movies Streaming HD Quality and Full Episode TV Shows for FREE",

    "sitekeywords"    => "full movie, full episode",

    "sitethemes"      => "g-blue",

    "offer_link1"     => "//look.ichlnk.com/offer?prod=3&ref=5043511",

    "offer_link2"     => "//look.ichlnk.com/offer?prod=3&ref=5043511",

    // "sport_offer"     => "",        // Jika Belum Di Include Plugin Sport nya gak bisa di gunakan

    "histatsID"       => "3907523",

    //================================================================================================

    "tvdb_search"     => "true",

    "cache"           => "true",

    "_seo"            => "true",

    "_stt"            => "true",

    "protect_content" => "true",       // disable klik kanan, block text, copy paste pada halaman LP

    "search_url"      => "search",

    "url_end"         => ".html",
    
    "category_url"    => "genre",
    
    "timezone"        => "America/Chicago",

    "debug"           => "true",

);

$alt_country2 = array(
    /*
    |--------------------------------------------------------------------------
    | Contoh Penulisan Country Code
    |--------------------------------------------------------------------------
    | 'US', 'GB', 'UK'
    | Contoh Dibawah Menandakan Negara ID (Indonesia) dan MY (Malaysia) 
    | Offer Link nya akan di redirect ke Offer Kedua
    |
    */
   
   'ID', 'MY', 'MX', 'RU'
);